// SPDX-License-Identifier: MIT
// npx hardhat test lib-tests.js --network pulsechain
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("LogicConstituent Tests", function () {
  // Set timeout to accommodate network latency
  this.timeout(300000); // 5 minutes
  
  let logicConstituent;
  let signer;
  
  before(async function () {
    console.log("Setting up test environment...");
    
    try {
      // Use the LogicConstituent contract address
      const logicConstituentAddress = "0x3A7F4dE971bE134d7EC5bAB764FA68aB747c7684";
      console.log("Using LogicConstituent at:", logicConstituentAddress);
      
      // Get a signer
      [signer] = await ethers.getSigners();
      console.log("Using signer:", signer.address);
      
      // Get the contract factory with ABI
      const LogicConstituent = await ethers.getContractFactory("LogicConstituent");
      
      // Create contract instance
      logicConstituent = LogicConstituent.attach(logicConstituentAddress);
      console.log("LogicConstituent instance created successfully");
    } catch (error) {
      console.error("Error in setup:", error);
      throw error;
    }
  });

  describe("Basic Contract Functions", function() {
    it("Should return the version", async function() {
      const version = await logicConstituent.version();
      console.log("LogicConstituent version:", version);
      expect(version).to.equal("1.0.0");
    });
    
    it("Should return the debug mode", async function() {
      const debugMode = await logicConstituent.getDebugMode();
      console.log("Current debug mode:", debugMode.toString());
      expect(debugMode.toString()).to.match(/^[01]$/);
    });
  });

  describe("Feature Validation Functions", function() {
    it("Should validate feature position", async function() {
      const featureId = 1;
      const cycle = 1;
      
      const result = await logicConstituent.validateFeaturePosition(featureId, cycle);
      console.log(`Feature position validation (featureId=${featureId}, cycle=${cycle}):`, result);
      expect(result).to.be.true;
      
      // Test with invalid cycle
      const invalidCycle = 13; // Beyond the 12 cycles
      const invalidResult = await logicConstituent.validateFeaturePosition(featureId, invalidCycle);
      console.log(`Feature position validation with invalid cycle (featureId=${featureId}, cycle=${invalidCycle}):`, invalidResult);
      expect(invalidResult).to.be.false;
    });
    
    it("Should validate NFT transfer", async function() {
      try {
        const caller = signer.address;
        const from = signer.address;
        const to = "0x64814a5c3f1EB67B59576AB0D61B5FeA854C69B8"; // Some valid address
        const amount = 1;
        const isApprovedOperator = true;
        
        const result = await logicConstituent.validateNFTTransfer(caller, from, to, amount, isApprovedOperator);
        console.log(`NFT transfer validation:`, result);
        expect(result).to.be.true;
        
        // Test with zero address
        const zeroAddress = "0x0000000000000000000000000000000000000000";
        const invalidResult = await logicConstituent.validateNFTTransfer(caller, from, zeroAddress, amount, isApprovedOperator);
        console.log(`NFT transfer validation with zero address:`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in NFT transfer validation test:", error.message);
        this.skip();
      }
    });
    
    it("Should validate NFT mint", async function() {
      try {
        const to = signer.address;
        const amount = 1;
        const tokenId = 1;
        
        const result = await logicConstituent.validateNFTMint(to, amount, tokenId);
        console.log(`NFT mint validation:`, result);
        expect(result).to.be.true;
        
        // Test with zero address
        const zeroAddress = "0x0000000000000000000000000000000000000000";
        const invalidResult = await logicConstituent.validateNFTMint(zeroAddress, amount, tokenId);
        console.log(`NFT mint validation with zero address:`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in NFT mint validation test:", error.message);
        this.skip();
      }
    });
  });
  
  describe("Validation Functions", function() {
    it("Should validate location coordinates", async function() {
      const validLatitude = 45;
      const validLongitude = 90;
      
      const result = await logicConstituent.validateLocationCoordinates(validLatitude, validLongitude);
      console.log(`Location coordinates validation (lat=${validLatitude}, long=${validLongitude}):`, result);
      expect(result).to.be.true;
      
      // Test with invalid coordinates
      const invalidLatitude = 100; // Outside -90 to 90 range
      const invalidResult = await logicConstituent.validateLocationCoordinates(invalidLatitude, validLongitude);
      console.log(`Location validation with invalid latitude (lat=${invalidLatitude}, long=${validLongitude}):`, invalidResult);
      expect(invalidResult).to.be.false;
    });
    
    it("Should validate Chiron stream", async function() {
      const locationId = 42;
      const timestamp = Math.floor(Date.now() / 1000); // Current timestamp
      
      const result = await logicConstituent.validateChironStream(locationId, timestamp);
      console.log(`Chiron stream validation (locationId=${locationId}, timestamp=${timestamp}):`, result);
      expect(result).to.be.true;
      
      // Test with invalid location
      const invalidLocationId = 0;
      const invalidResult = await logicConstituent.validateChironStream(invalidLocationId, timestamp);
      console.log(`Chiron stream validation with invalid location (locationId=${invalidLocationId}, timestamp=${timestamp}):`, invalidResult);
      expect(invalidResult).to.be.false;
    });
    
    it("Should validate Chiron slot", async function() {
      try {
        const locationId = 42;
        const slotId = 3;
        const patternValue = 925925926; // Stage 1 value
        const durationMs = 300000; // 5 minutes
        
        const result = await logicConstituent.validateChironSlot(locationId, slotId, patternValue, durationMs);
        console.log(`Chiron slot validation (locationId=${locationId}, slotId=${slotId}):`, result);
        expect(result).to.be.true;
        
        // Test with invalid location ID
        const invalidLocationId = 0;
        const invalidResult = await logicConstituent.validateChironSlot(invalidLocationId, slotId, patternValue, durationMs);
        console.log(`Chiron slot validation with invalid location (locationId=${invalidLocationId}):`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in Chiron slot validation test:", error.message);
        this.skip();
      }
    });
    
    it("Should validate liquidity amount", async function() {
      try {
        const amount = 1000000000; // 1 token
        const userBalance = 2000000000; // 2 tokens
        
        const result = await logicConstituent.validateLiquidityAmount(amount, userBalance);
        console.log(`Liquidity amount validation (amount=${amount}, balance=${userBalance}):`, result);
        expect(result).to.be.true;
        
        // Test with amount exceeding balance
        const excessAmount = 3000000000; // 3 tokens
        const invalidResult = await logicConstituent.validateLiquidityAmount(excessAmount, userBalance);
        console.log(`Liquidity validation with excess amount (amount=${excessAmount}, balance=${userBalance}):`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in liquidity amount validation test:", error.message);
        this.skip();
      }
    });
  });
  
  describe("Math Functions", function() {
    it("Should calculate staking bonus", async function() {
      const stakeDuration = 60 * 60 * 24 * 31; // 31 days in seconds
      const stakeAmount = 1000000000; // 1 token in appropriate units
      
      const bonus = await logicConstituent.calculateStakingBonus(stakeDuration, stakeAmount);
      console.log(`Staking bonus (duration=${stakeDuration}, amount=${stakeAmount}):`, bonus.toString());
      
      // For durations > 30 days, bonus should be 5% of stake amount
      const expectedBonus = Math.floor(stakeAmount * 5 / 100);
      expect(bonus.toString()).to.equal(expectedBonus.toString());
      
      // Test with duration under threshold
      const shortDuration = 60 * 60 * 24 * 29; // 29 days
      const shortBonus = await logicConstituent.calculateStakingBonus(shortDuration, stakeAmount);
      console.log(`Staking bonus for short duration (duration=${shortDuration}, amount=${stakeAmount}):`, shortBonus.toString());
      expect(shortBonus.toString()).to.equal("0");
    });
    
    it("Should calculate market impact", async function() {
      try {
        const amount = 1000000000; // 1 token in appropriate units
        const dailyAllocation = 86400000000; // Daily allocation
        
        const impact = await logicConstituent.calculateMarketImpact(amount, dailyAllocation);
        console.log(`Market impact (amount=${amount}, dailyAllocation=${dailyAllocation}):`, impact.toString());
        
        // Impact should be non-zero
        expect(impact.toString()).to.not.equal("0");
        
        // Test with larger amount - impact should be higher
        const largerAmount = amount * 2;
        const largerImpact = await logicConstituent.calculateMarketImpact(largerAmount, dailyAllocation);
        console.log(`Market impact with larger amount (amount=${largerAmount}):`, largerImpact.toString());
        expect(Number(largerImpact.toString())).to.be.greaterThan(Number(impact.toString()));
      } catch (error) {
        console.log("Error in market impact calculation test:", error.message);
        this.skip();
      }
    });
    
    it("Should calculate liquidity reward", async function() {
      try {
        const amount = 1000000000; // 1 token
        const totalLiquidity = 10000000000; // Total liquidity
        const rewardRate = 100000000; // Reward rate
        
        const reward = await logicConstituent.calculateLiquidityReward(amount, totalLiquidity, rewardRate);
        console.log(`Liquidity reward (amount=${amount}, totalLiquidity=${totalLiquidity}, rewardRate=${rewardRate}):`, reward.toString());
        
        // Calculate expected reward: (amount * rewardRate) / totalLiquidity
        const expectedReward = Math.floor((amount * rewardRate) / totalLiquidity);
        expect(reward.toString()).to.equal(expectedReward.toString());
      } catch (error) {
        console.log("Error in liquidity reward calculation test:", error.message);
        this.skip();
      }
    });
  });
  
  describe("Governance Functions", function() {
    it("Should validate quorum", async function() {
      try {
        const totalVotes = 100;
        const forVotes = 60;
        const againstVotes = 40;
        const votedMembers = 10;
        const activeMemberCount = 20;
        const currentStage = 1;
        
        const result = await logicConstituent.validateQuorum(
          totalVotes, forVotes, againstVotes, votedMembers, activeMemberCount, currentStage
        );
        console.log(`Quorum validation:`, result);
        
        // Test with more against votes than for
        const lessForVotes = 30;
        const moreAgainstVotes = 70;
        const invalidResult = await logicConstituent.validateQuorum(
          totalVotes, lessForVotes, moreAgainstVotes, votedMembers, activeMemberCount, currentStage
        );
        console.log(`Quorum validation with more against votes:`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in quorum validation test:", error.message);
        this.skip();
      }
    });
    
    it("Should validate stage transitions", async function() {
      try {
        const currentStage = 1;
        const proposedStage = 2;
        const forVotes = 60;
        const againstVotes = 40;
        const activeMemberCount = 20;
        
        const result = await logicConstituent.validateStageTransition(
          currentStage, proposedStage, forVotes, againstVotes, activeMemberCount
        );
        console.log(`Stage transition validation:`, result);
        
        // Test with non-sequential transition
        const skipStage = 3; // Skipping stage 2
        const invalidResult = await logicConstituent.validateStageTransition(
          currentStage, skipStage, forVotes, againstVotes, activeMemberCount
        );
        console.log(`Stage transition validation with non-sequential stage:`, invalidResult);
        expect(invalidResult).to.be.false;
      } catch (error) {
        console.log("Error in stage transition validation test:", error.message);
        this.skip();
      }
    });
    
    it("Should validate stage duration", async function() {
      try {
        const stage = 1;
        const minDuration = 24 * 60 * 60; // 1 day in seconds
        
        const result = await logicConstituent.validateStageDuration(stage, minDuration);
        console.log(`Stage duration validation (stage=${stage}, duration=${minDuration}):`, result);
        
        // Test with very short duration (should fail)
        const shortDuration = 60 * 60; // 1 hour
        const invalidResult = await logicConstituent.validateStageDuration(stage, shortDuration);
        console.log(`Stage duration validation with short duration (duration=${shortDuration}):`, invalidResult);
      } catch (error) {
        console.log("Error in stage duration validation test:", error.message);
        this.skip();
      }
    });
  });
});
