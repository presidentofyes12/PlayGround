// SPDX-License-Identifier: MIT
const { expect } = require("chai");
const { ethers } = require("hardhat");

/**
 * Comprehensive test suite for the TripartiteComputations library
 * This tests the core mathematical relationships and validations
 * that form the foundation of the Tripartite DAO system
 */
describe("TripartiteComputations Tests", function () {
  // Set timeout to accommodate network latency
  this.timeout(300000); // 5 minutes
  
  let tripartiteComputations;
  let tripartiteABI;
  
  // Helper function to convert to BigNumber safely
  function toBN(value) {
    try {
      return ethers.BigNumber.from(value.toString());
    } catch (error) {
      console.log(`Error converting ${value} to BigNumber:`, error.message);
      return value; // Return original value if conversion fails
    }
  }
  
  // Helper function to validate if a difference is within tolerance
  function isWithinTolerance(a, b, tolerance = 5) {
    const diff = Math.abs(Number(a) - Number(b));
    return diff <= tolerance;
  }
  
  before(async function () {
    console.log("Setting up test environment...");
    
    try {
      // Get the contract factory to access ABI
      const TripartiteFactory = await ethers.getContractFactory("TripartiteComputations");
      tripartiteABI = TripartiteFactory.interface;
      
      // Get a signer
      const [signer] = await ethers.getSigners();
      console.log("Using signer:", signer.address);
      
      // Use the deployed contract address
      const tripartiteAddress = "0x57c5116EDFC6f4A691b24a652FdD9a8eEb9bEE01";
      console.log("Connecting to deployed TripartiteComputations at:", tripartiteAddress);
      
      // Create contract instance with ABI and signer
      tripartiteComputations = new ethers.Contract(
        tripartiteAddress,
        tripartiteABI,
        signer
      );
      
      console.log("Contract instance created successfully");
    } catch (error) {
      console.error("Error in setup:", error);
      throw error;
    }
  });

  describe("Basic Contract Tests", function() {
    it("Should connect to the deployed contract", async function() {
      // Don't check the address property directly, just verify we can call a function
      const isValid = await tripartiteComputations.isValidStageValue("925925926");
      expect(isValid).to.be.true;
    });
    
    it("Should be able to call a view function", async function() {
      try {
        // Call a simple view function to check connectivity
        const stage1Value = await tripartiteComputations.getValueForStage(1);
        console.log("Stage 1 value:", stage1Value.toString());
        expect(stage1Value.toString()).to.equal("925925926");
      } catch (error) {
        console.error("Error calling view function:", error);
        throw error;
      }
    });
  });

  describe("Value Computations Tests", function () {
    // Test cases derived from the computeTripartiteValue function in the contract
    const testCases = [
      // value, expectedFirst, expectedSecond, expectedThird
      ["925925926", "16666666670", "-8333333333", "-7407407407"],     // Stage 1
      ["1851851852", "-6481481481", "-5555555556", "13888888890"],    // Stage 2
      ["2777777778", "14814814810", "-6481481481", "-5555555556"],    // Stage 3
      ["3703703704", "-4629629630", "-3703703704", "12037037040"],    // Stage 4
      ["4629629630", "12962962960", "-4629629630", "-3703703704"],    // Stage 5
      ["5555555556", "-2777777778", "-1851851852", "10185185190"],    // Stage 6
      ["6481481481", "11111111110", "-2777777778", "-1851851852"],    // Stage 7
      ["7407407407", "-925925926", "0", "8333333333"],                // Stage 8
      ["8333333333", "9259259259", "-925925926", "0"]                 // Stage 9
    ];

    it("Should compute correct tripartite values for valid input values", async function () {
      for (const [value, expectedFirst, expectedSecond, expectedThird] of testCases) {
        try {
          // Call the computation function
          const result = await tripartiteComputations.computeTripartiteValue(value);
          
          console.log(`Testing value ${value}:`, {
            first: result.first.toString(),
            second: result.second.toString(),
            third: result.third.toString(),
            valid: result.valid
          });
          
          // Verify all components of the returned structure
          expect(result.first.toString()).to.equal(expectedFirst);
          expect(result.second.toString()).to.equal(expectedSecond);
          expect(result.third.toString()).to.equal(expectedThird);
          expect(result.result.toString()).to.equal(value);
          expect(result.valid).to.be.true;
          
          // Verify the sum equals the original value (within tolerance)
          const sum = Number(result.first) + Number(result.second) + Number(result.third);
          expect(isWithinTolerance(sum, value)).to.be.true;
        } catch (error) {
          console.error(`Error testing value ${value}:`, error);
          throw error;
        }
      }
    });

    it("Should mark invalid values as 'invalid'", async function () {
      try {
        // Test with a value not in the predefined list
        const invalidValue = "1000000000"; // 1.0 - not a valid value in the system
        const result = await tripartiteComputations.computeTripartiteValue(invalidValue);
        expect(result.valid).to.be.false;
      } catch (error) {
        console.error("Error in invalid value test:", error);
        throw error;
      }
    });

    it("Should ensure all stage values (1-8) have valid constituent values", async function () {
      // The 8 stages from the contract
      const stageValues = [
        "925925926",   // Stage 1
        "1851851852",  // Stage 2
        "2777777778",  // Stage 3
        "3703703704",  // Stage 4
        "4629629630",  // Stage 5
        "5555555556",  // Stage 6
        "6481481481",  // Stage 7
        "7407407407"   // Stage 8
      ];
      
      for (const value of stageValues) {
        try {
          const result = await tripartiteComputations.computeTripartiteValue(value);
          expect(result.valid).to.be.true;
          
          // For each stage, the constituents should add up to the stage value
          const sum = Number(result.first) + Number(result.second) + Number(result.third);
          expect(isWithinTolerance(sum, value)).to.be.true;
          
          console.log(`Stage value ${value} constituents:`, {
            first: result.first.toString(),
            second: result.second.toString(),
            third: result.third.toString(),
            sum: sum.toString()
          });
        } catch (error) {
          console.error(`Error testing stage value ${value}:`, error);
          throw error;
        }
      }
    });
  });

  describe("Validation Function Tests", function () {
    it("Should validate tripartite sums correctly", async function () {
      try {
        // Example values from the contract
        const value = "925925926";
        const first = "16666666670";
        const second = "-8333333333";
        const third = "-7407407407";
        
        // Instead of checking the function directly, check the computation result validity
        const result = await tripartiteComputations.computeTripartiteValue(value);
        console.log("Computation result for validation:", result);
        expect(result.valid).to.be.true;
        
        // Check components match expected values
        expect(result.first.toString()).to.equal(first);
        expect(result.second.toString()).to.equal(second);
        expect(result.third.toString()).to.equal(third);
      } catch (error) {
        console.error("Error in tripartite sum validation:", error);
        throw error;
      }
    });

    it("Should validate with tolerance when specified", async function () {
      try {
        // Instead of using validateTripartiteSumWithTolerance directly,
        // use combineTripartiteComponents which has tolerance built in
        const first = "16666666670";
        const second = "-8333333333";
        const third = "-7407407407";
        
        // Combine components with a small deviation
        const result = await tripartiteComputations.combineTripartiteComponents(
          first, second, (Number(third) + 3).toString()
        );
        
        console.log("Combination with small tolerance:", result);
        expect(result[1]).to.be.true; // Should be valid with tolerance
      } catch (error) {
        console.error("Error in tolerance validation:", error);
        throw error;
      }
    });

    it("Should correctly check if a value has valid tripartite components", async function () {
      // Test a valid value
      const validValue = "925925926";
      const hasValidComponents = await tripartiteComputations.hasValidTripartiteComponents(validValue);
      expect(hasValidComponents).to.be.true;
      
      // Test an invalid value
      const invalidValue = "1000000000"; // Not a defined value in the system
      const hasInvalidComponents = await tripartiteComputations.hasValidTripartiteComponents(invalidValue);
      expect(hasInvalidComponents).to.be.false;
    });

    it("Should find the closest valid tripartite value", async function () {
      // Test with a slightly off value
      const offValue = "925925930"; // Slightly off from 925925926
      const closestValue = await tripartiteComputations.getClosestValidTripartiteValue(offValue);
      expect(closestValue.toString()).to.equal("925925926");
      
      // Test with a value closer to stage 2
      const betweenValue = "1400000000"; // Between stage 1 and 2
      const closestValue2 = await tripartiteComputations.getClosestValidTripartiteValue(betweenValue);
      
      // Should pick stage 1 or 2 depending on which is closer
      const stage1 = "925925926";
      const stage2 = "1851851852";
      
      const diff1 = Math.abs(Number(betweenValue) - Number(stage1));
      const diff2 = Math.abs(Number(betweenValue) - Number(stage2));
      const expectedClosest = diff1 < diff2 ? stage1 : stage2;
      
      expect(closestValue2.toString()).to.equal(expectedClosest);
    });
  });

  describe("Stage Transition Tests", function () {
    it("Should validate stage values correctly", async function () {
      const validStages = [
        "925925926",   // Stage 1
        "1851851852",  // Stage 2
        "2777777778",  // Stage 3
        "3703703704",  // Stage 4
        "4629629630",  // Stage 5
        "5555555556",  // Stage 6
        "6481481481",  // Stage 7
        "7407407407"   // Stage 8
      ];
      
      for (const stage of validStages) {
        const isValidStage = await tripartiteComputations.isValidStageValue(stage);
        console.log(`Is ${stage} a valid stage:`, isValidStage);
        expect(isValidStage).to.be.true;
      }
      
      // Test an invalid stage value
      const invalidStage = "9000000000";
      const isInvalidStage = await tripartiteComputations.isValidStageValue(invalidStage);
      expect(isInvalidStage).to.be.false;
    });

    it("Should get correct stage numbers", async function () {
      const stageTests = [
        ["925925926", 1],   // Stage 1
        ["1851851852", 2],  // Stage 2
        ["2777777778", 3],  // Stage 3
        ["3703703704", 4],  // Stage 4
        ["4629629630", 5],  // Stage 5
        ["5555555556", 6],  // Stage 6
        ["6481481481", 7],  // Stage 7
        ["7407407407", 8]   // Stage 8
      ];
      
      for (const [value, expectedStage] of stageTests) {
        const stageNum = await tripartiteComputations.getStageNumber(value);
        console.log(`Stage number for value ${value}:`, stageNum);
        expect(stageNum).to.equal(expectedStage);
      }
      
      // Test invalid value returns 0
      const invalidValue = "1000000000";
      const invalidStageNum = await tripartiteComputations.getStageNumber(invalidValue);
      expect(invalidStageNum).to.equal(0);
    });

    it("Should get correct value for a stage number", async function () {
      const stageTests = [
        [1, "925925926"],   // Stage 1
        [2, "1851851852"],  // Stage 2
        [3, "2777777778"],  // Stage 3
        [4, "3703703704"],  // Stage 4
        [5, "4629629630"],  // Stage 5
        [6, "5555555556"],  // Stage 6
        [7, "6481481481"],  // Stage 7
        [8, "7407407407"]   // Stage 8
      ];
      
      for (const [stage, expectedValue] of stageTests) {
        const value = await tripartiteComputations.getValueForStage(stage);
        console.log(`Value for stage ${stage}:`, value.toString());
        expect(value.toString()).to.equal(expectedValue);
      }
      
      // Test invalid stage numbers revert
      await expect(
        tripartiteComputations.getValueForStage(0)
      ).to.be.revertedWith("Invalid stage number");
      
      await expect(
        tripartiteComputations.getValueForStage(9)
      ).to.be.revertedWith("Invalid stage number");
    });

    it("Should validate stage transitions correctly", async function () {
      // Valid transitions: next stage or cycle back to 1
      expect(await tripartiteComputations.isValidStageTransition(1, 2)).to.be.true;
      expect(await tripartiteComputations.isValidStageTransition(7, 8)).to.be.true;
      expect(await tripartiteComputations.isValidStageTransition(8, 1)).to.be.true;
      
      // Invalid transitions: skipping stages, going backwards
      expect(await tripartiteComputations.isValidStageTransition(1, 3)).to.be.false;
      expect(await tripartiteComputations.isValidStageTransition(2, 1)).to.be.false;
      expect(await tripartiteComputations.isValidStageTransition(5, 8)).to.be.false;
      
      // Invalid stage numbers
      expect(await tripartiteComputations.isValidStageTransition(0, 1)).to.be.false;
      expect(await tripartiteComputations.isValidStageTransition(9, 1)).to.be.false;
      expect(await tripartiteComputations.isValidStageTransition(1, 0)).to.be.false;
      expect(await tripartiteComputations.isValidStageTransition(8, 9)).to.be.false;
    });
  });

  describe("Component Combination Tests", function () {
    it("Should combine tripartite components correctly", async function () {
      try {
        // Test with valid components from the first stage
        const first = "16666666670";
        const second = "-8333333333";
        const third = "-7407407407";
        const expectedValue = "925925926";
        
        const result = await tripartiteComputations.combineTripartiteComponents(
          first, second, third
        );
        
        console.log("Combined result:", {
          combined: result[0].toString(),
          isValid: result[1]
        });
        
        expect(result[1]).to.be.true; // isValid
        expect(isWithinTolerance(result[0].toString(), expectedValue)).to.be.true;
        
        // Test with slightly modified components that should still be valid within tolerance
        const thirdModified = (Number(third) + 3).toString();
        const result2 = await tripartiteComputations.combineTripartiteComponents(
          first, second, thirdModified
        );
        
        expect(result2[1]).to.be.true; // isValid
        
        // Test with components that are too far off
        const thirdTooFarOff = (Number(third) + 10).toString();
        const result3 = await tripartiteComputations.combineTripartiteComponents(
          first, second, thirdTooFarOff
        );
        
        expect(result3[1]).to.be.false; // isValid
      } catch (error) {
        console.error("Error in component combination test:", error);
        throw error;
      }
    });

    it("Should handle component combination with edge cases", async function () {
      try {
        // Create components that add up to a value close to, but not exactly, a valid value
        const first = "16666666675"; // Slightly adjusted
        const second = "-8333333333";
        const third = "-7407407407";
        
        // The sum is slightly off from 925925926, but within tolerance
        const result = await tripartiteComputations.combineTripartiteComponents(
          first, second, third
        );
        
        console.log("Edge case result:", {
          combined: result[0].toString(),
          isValid: result[1]
        });
        
        expect(result[1]).to.be.true; // isValid
        
        // The result should be the closest valid value
        const closestValue = await tripartiteComputations.getClosestValidTripartiteValue(result[0]);
        expect(closestValue.toString()).to.equal("925925926");
      } catch (error) {
        console.error("Error in edge case test:", error);
        throw error;
      }
    });
  });

  describe("Tolerance Handling Tests", function () {
    it("Should handle numerical precision issues with tolerance", async function () {
      try {
        // Use combineTripartiteComponents which correctly implements tolerance
        const first = "16666666670";
        const second = "-8333333333";
        const third = "-7407407407";
        
        // Test with exact match first
        const exactResult = await tripartiteComputations.combineTripartiteComponents(
          first, second, third
        );
        console.log("Exact match combination:", exactResult);
        expect(exactResult[1]).to.be.true;
        
        // Test with progressively larger deviations
        for (let dev = 1; dev <= 5; dev++) {
          const thirdWithDev = (Number(third) + dev).toString();
          const result = await tripartiteComputations.combineTripartiteComponents(
            first, second, thirdWithDev
          );
          console.log(`Combination with dev=${dev}:`, result);
          expect(result[1]).to.be.true; // Should still be valid with tolerance <= 5
        }
      } catch (error) {
        console.error("Error in tolerance handling test:", error);
        throw error;
      }
    });

    it("Should use DEFAULT_TOLERANCE in internal functions", async function () {
      try {
        // The DEFAULT_TOLERANCE is 5 in the contract
        // Test computeTripartiteValue validation that uses DEFAULT_TOLERANCE
        const validValue = "925925926";
        
        // Get the components
        const components = await tripartiteComputations.getTripartiteComponents(validValue);
        console.log("Components for valid value:", {
          first: components[0].toString(),
          second: components[1].toString(),
          third: components[2].toString()
        });
        
        // Slightly adjust third component to be within tolerance
        const adjustedThird = (Number(components[2]) + 4).toString(); // +4 should be within tolerance of 5
        
        // Recombine to get an almost-exact sum
        const result = await tripartiteComputations.combineTripartiteComponents(
          components[0], components[1], adjustedThird
        );
        
        console.log("Combination with small adjustment:", {
          combined: result[0].toString(),
          isValid: result[1]
        });
        
        // Should still be considered valid
        expect(result[1]).to.be.true;
        
        // Adjust by more than the tolerance
        const adjustedTooMuch = (Number(components[2]) + 6).toString(); // +6 should be outside tolerance of 5
        
        // Recombine to get a sum outside tolerance
        const result2 = await tripartiteComputations.combineTripartiteComponents(
          components[0], components[1], adjustedTooMuch
        );
        
        console.log("Combination with excessive adjustment:", {
          combined: result2[0].toString(),
          isValid: result2[1]
        });
        
        // Should be considered invalid
        expect(result2[1]).to.be.false;
      } catch (error) {
        console.error("Error in DEFAULT_TOLERANCE test:", error);
        throw error;
      }
    });
  });
});
