import { TypedEventEmitter } from "raven/helper/event-emitter";
import * as Comlink from "comlink";
import chunk from "lodash.chunk";
import uniq from "lodash.uniq";
import { nip04, utils, SimplePool } from "nostr-tools";
import { BgRaven } from "raven/worker";
import { getRelays } from "local-storage";
import { GLOBAL_CHAT, MESSAGE_PER_PAGE } from "const";
import { toast } from "react-toastify";
import {
  PrivKey,
  Channel,
  ChannelMessageHide,
  ChannelUpdate,
  ChannelUserMute,
  DirectMessage,
  EventDeletion,
  Keys,
  Metadata,
  MuteList,
  Profile,
  PublicMessage,
  Reaction,
  ReadMarkMap,
  RelayDict,
  OrderStatus,
  Order,
  Product,
  Stall,
  Proposal
} from "types";
import { notEmpty } from "util/misc";
import { isSha256 } from "util/crypto";
import { generateWeb3Keys, registerDataOnChain } from "util/function";
import { contractAddress, plateformProposalKey } from "util/constant";
import { NostrEvent, NostrFilter, NostrKind, NostrSimplePool } from "../types/nostr";
interface EventSuggestion {
  id: string;
  root: string;
  content: string;
  creator: string;
  created: number;
  mentions: string[];
  proposalID: string;
}

let relays: RelayDict;
getRelays().then(r => {
  relays = r;
});

export enum NewKinds {
  MuteList = 10000,
  Arbitrary = 30078,
  CalendarSuggestion = 30079,
}

export type AllKinds = NostrKind | NewKinds;

export type ExtendedFilter = Omit<NostrFilter, 'kinds'> & { kinds?: AllKinds[] };

// Add this type to combine NostrKind and NewKinds
export type ExtendedKind = NostrKind | NewKinds;

export enum RavenEvents {
  Ready = 'ready',
  DMsDone = 'dms_done',
  SyncDone = 'sync_done',
  ProfileUpdate = 'profile_update',
  ChannelCreation = 'channel_creation',
  ChannelUpdate = 'channel_update',
  EventDeletion = 'event_deletion',
  PublicMessage = 'public_message',
  DirectMessage = 'direct_message',
  ChannelMessageHide = 'channel_message_hide',
  ChannelUserMute = 'channel_user_mute',
  MuteList = 'mute_list',
  LeftChannelList = 'left_channel_list',
  Reaction = 'reaction',
  ReadMarkMap = 'read_mark_map',
  CalendarSuggestion = 'calendar_suggestion',
}

type EventHandlerMap = {
  [RavenEvents.Ready]: () => void;
  [RavenEvents.DMsDone]: () => void;
  [RavenEvents.SyncDone]: () => void;
  [RavenEvents.ProfileUpdate]: (data: Profile[]) => void;
  [RavenEvents.ChannelCreation]: (data: Channel[]) => void;
  [RavenEvents.ChannelUpdate]: (data: ChannelUpdate[]) => void;
  [RavenEvents.EventDeletion]: (data: EventDeletion[]) => void;
  [RavenEvents.PublicMessage]: (data: PublicMessage[]) => void;
  [RavenEvents.DirectMessage]: (data: DirectMessage[]) => void;
  [RavenEvents.ChannelMessageHide]: (data: ChannelMessageHide[]) => void;
  [RavenEvents.ChannelUserMute]: (data: ChannelUserMute[]) => void;
  [RavenEvents.MuteList]: (data: MuteList) => void;
  [RavenEvents.LeftChannelList]: (data: string[]) => void;
  [RavenEvents.Reaction]: (data: Reaction[]) => void;
  [RavenEvents.ReadMarkMap]: (data: ReadMarkMap) => void;
  [RavenEvents.CalendarSuggestion]: (data: EventSuggestion[]) => void;
};

export function initRaven(priv: string, pub: string): Raven {
  return new Raven(priv, pub);
}

export class Raven extends TypedEventEmitter<RavenEvents, EventHandlerMap> {
  static parseJson(content: string): any {
    try {
      return JSON.parse(content);
    } catch {
      return null;
    }
  }

  static normalizeMetadata(content: any): { name: string; about: string; picture: string } {
    return {
      name: content.name || '',
      about: content.about || '',
      picture: content.picture || '',
    };
  }

  static findTagValue(ev: NostrEvent, tag: 'e' | 'p' | 'd'): string | undefined {
    return ev.tags.find(([t]) => t === tag)?.[1];
  }

  static filterTagValue(ev: NostrEvent, tag: 'e' | 'p' | 'd'): string[][] {
    return ev.tags.filter(([t]) => t === tag);
  }

  static findNip10MarkerValue(ev: NostrEvent, marker: 'reply' | 'root' | 'mention'): string | undefined {
    const eTags = Raven.filterTagValue(ev, 'e');
    return eTags.find(x => x[3] === marker)?.[1];
  }
  private readonly worker: Worker;
  private bgRaven: Comlink.Remote<BgRaven>;

  private readonly priv: PrivKey;
  private readonly pub: string;

  private readonly readRelays = Object.keys(relays).filter(r => relays[r].read);
  private readonly writeRelays = Object.keys(relays).filter(
    r => relays[r].write
  );
  
  private eventQueue: NostrEvent[] = [];
  private eventQueueTimer: any;
  private eventQueueFlag = true;
  private eventQueueBuffer: NostrEvent[] = [];

  private nameCache: Record<string, number> = {};

  listenerSub: string | null = null;
  messageListenerSub: string | null = null;

  constructor(priv: string, pub: string) {
    super();

    this.priv = priv;
    this.pub = pub;

    // Raven is all about relay/pool management through websockets using timers.
    // Browsers (chrome) slows down timer tasks when the window goes to inactive.
    // That is why we use a web worker to read data from relays.
    this.worker = new Worker(new URL('worker.ts', import.meta.url));
    this.bgRaven = Comlink.wrap<BgRaven>(this.worker);
    this.bgRaven.setup(this.readRelays).then();

    if (priv && pub) this.init().then();
  }
  
  get getPub(): string {
    return this.pub;
  }
  
  private async init() {
    // 1- Get all event created by the user
    const events = await this.fetch([
      {
        authors: [this.pub],
      },
    ]);
    events
      .filter(e => e.kind !== NostrKind.ChannelMessage) // public messages comes with channel requests
      .forEach(e => this.pushToEventBuffer(e));
    this.emit(RavenEvents.Ready);

    // 2- Get all incoming DMs to the user
    const incomingDms = await this.fetch([
      {
        kinds: [NostrKind.EncryptedDirectMessage],
        '#p': [this.pub],
      },
    ]);
    incomingDms.forEach(e => this.pushToEventBuffer(e));
    this.emit(RavenEvents.DMsDone);

    // 3- Get channels messages
    // Build channel ids
    const deletions = events
      .filter(x => x.kind === NostrKind.EventDeletion)
      .map(x => Raven.findTagValue(x, 'e'))
      .filter(notEmpty);

    const channelIds = uniq(
      events
        .map(x => {
          if (x.kind === NostrKind.ChannelCreation) {
            return x.id;
          }

          if (x.kind === NostrKind.ChannelMessage) {
            return Raven.findTagValue(x, 'e');
          }

          return null;
        })
        .filter(notEmpty)
        .filter(x => !deletions.includes(x))
        .filter(notEmpty)
    );

    if (!channelIds.includes(GLOBAL_CHAT.id)) {
      channelIds.push(GLOBAL_CHAT.id);
    }

    // Get real channel list over the channel list collected from channel creations + public messages sent.
    const channels = await this.fetch([
      ...chunk(channelIds, 10).map(x => ({
        kinds: [NostrKind.ChannelCreation],
        ids: x,
      })),
    ]);
    const publicProposal = await this.fetch([
      {
        kinds: [NostrKind.ChannelMetadata],
        '#p': [plateformProposalKey],
      },
    ]);
    console.log('Public Proposal', publicProposal);
    console.log('All of Proposal', events);
    console.log('Filtered Proposal', channels);
    channels.forEach(x => this.pushToEventBuffer(x));

    // Get messages for all channels found
    const filters = channels
      .map(x => x.id)
      .map(x => [
        {
          kinds: [NostrKind.ChannelMetadata, NostrKind.EventDeletion],
          '#e': [x],
        },
        {
          kinds: [NostrKind.ChannelMessage],
          '#e': [x],
          limit: MESSAGE_PER_PAGE,
        },
      ])
      .flat();

    const promises = chunk(filters, 6).map(f =>
      this.fetch(f).then(events =>
        events.forEach(ev => this.pushToEventBuffer(ev))
      )
    );
    await Promise.all(promises);

    this.emit(RavenEvents.SyncDone);
  }

  public isSyntheticPrivKey = () => {
    return this.priv === 'nip07' || this.priv === 'none';
  };

  public fetchPrevMessages(channel: string, until: number) {
    return this.fetch(
      [
        {
          kinds: [NostrKind.ChannelMessage],
          '#e': [channel],
          until,
          limit: MESSAGE_PER_PAGE,
        },
      ],
      1000
    ).then(events => {
      events.forEach(ev => {
        this.pushToEventBuffer(ev);
      });

      return events.length;
    });
  }

public async fetchAllProposal() {
  const filters: (NostrFilter | ExtendedFilter)[] = [
    {
      kinds: [NostrKind.ChannelMetadata],
      '#p': [plateformProposalKey],
    }
  ];

    return await this.fetch(filters);
  }

public async fetchCalendarSuggestions(): Promise<NostrEvent[]> {
  return this.fetch([
    {
      kinds: [NewKinds.CalendarSuggestion],
    }
  ]);
}

public async publishCalendarSuggestion(pubkey: string, suggestion: string): Promise<NostrEvent> {
  return this.publish(NewKinds.CalendarSuggestion, [['p', pubkey]], suggestion);
}

public onCalendarSuggestion(callback: (suggestions: EventSuggestion[]) => void) {
  this.on(RavenEvents.CalendarSuggestion, callback);
}

public offCalendarSuggestion(callback: (suggestions: EventSuggestion[]) => void) {
  this.off(RavenEvents.CalendarSuggestion, callback);
}

public async fetchChannel(id: string): Promise<Channel | null> {
  console.log('my channel id', id);
  const filters: (NostrFilter | ExtendedFilter)[] = [
    {
      kinds: [NostrKind.ChannelCreation],
      ids: [id],
    },
      {
        kinds: [NostrKind.ChannelMetadata, NostrKind.EventDeletion],
        '#e': [id],
      },
    ];

    const events = await this.fetch(filters);
    if (events.length === 0) return null; // Not found

    const creation = events.find(x => x.kind === NostrKind.ChannelCreation);
    if (!creation) return null; // Not found

    if (
      events.find(
        x => x.kind === NostrKind.EventDeletion && x.pubkey === creation.pubkey
      )
    )
      return null; // Deleted

    const update = events
      .filter(
        x => x.kind === NostrKind.ChannelMetadata && x.pubkey === creation.pubkey
      )
      .sort((a, b) => b.created_at - a.created_at)[0]; // Find latest metadata update

    const content = Raven.parseJson((update || creation).content);
    if (!content) return null; // Invalid content

    return {
      id: creation.id,
      creator: creation.pubkey,
      created: creation.created_at,
      ...Raven.normalizeMetadata(content),
    };
  }

  public async fetchProfile(pub: string): Promise<Profile | null> {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.Metadata],
        authors: [pub],
      },
    ];

    const ev = (await this.fetch(filters)).sort(
      (a, b) => b.created_at - a.created_at
    )[0];
    if (!ev) return null; // Not found

    const content = Raven.parseJson(ev.content);
    if (!content) return null; // Invalid content

    return {
      id: ev.id,
      creator: ev.pubkey,
      created: ev.created_at,
      ...Raven.normalizeMetadata(content),
      nip05: content.nip05,
    };
  }

private fetch(filters: (NostrFilter | ExtendedFilter)[], quitMs: number = 0): Promise<NostrEvent[]> {
  const nostrFilters = filters.map(filter => this.convertToNostrFilter(filter));
  return this.bgRaven.fetch(nostrFilters, quitMs);
}

private sub(filters: (NostrFilter | ExtendedFilter)[], unsub: boolean = true) {
  console.log('Subscribing to filters:', filters);
  const nostrFilters = filters.map(filter => this.convertToNostrFilter(filter));
  return this.bgRaven.sub(
    nostrFilters,
    Comlink.proxy((e: NostrEvent) => {
      console.log('Received event from subscription:', e);
      this.pushToEventBuffer(e);
    }),
    unsub
  );
}

private convertToNostrFilter(filter: NostrFilter | ExtendedFilter): NostrFilter {
  if ('kinds' in filter && filter.kinds) {
    return {
      ...filter,
      kinds: filter.kinds.filter((kind): kind is NostrKind => typeof kind === 'number') as NostrKind[]
    };
  }
  return filter as NostrFilter;
}

  private unsub(subId: string) {
    return this.bgRaven.unsub(subId);
  }

  public loadChannel(id: string) {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.ChannelCreation],
        ids: [id],
      },
      {
        kinds: [NostrKind.ChannelMetadata, NostrKind.EventDeletion],
        '#e': [id],
      },
      {
        kinds: [NostrKind.ChannelMessage],
        '#e': [id],
        limit: MESSAGE_PER_PAGE,
      },
    ];

    this.sub(filters);
  }

  public loadProfiles(pubs: string[]) {
    const authors = uniq(pubs).filter(p => this.nameCache[p] === undefined);
    if (authors.length === 0) {
      return;
    }
    authors.forEach(a => (this.nameCache[a] = Date.now()));

    chunk(authors, 20).forEach(a => {
      this.sub([
        {
          kinds: [NostrKind.Metadata],
          authors: a,
        },
      ]);
    });
  }

public listen(channels: string[], since: number) {
  console.log('Setting up listener', { channels, since });
  if (this.listenerSub) {
    console.log('Unsubscribing from previous listener');
    this.unsub(this.listenerSub).then();
  }

  this.sub(
    [
      {
        authors: [this.pub],
        since,
      },
      {
        kinds: [
          NostrKind.EventDeletion,
          NostrKind.ChannelMetadata,
          NostrKind.ChannelMessage,
        ],
        '#e': channels,
        since,
      },
      {
        kinds: [NostrKind.EncryptedDirectMessage],
        '#p': [this.pub],
        since,
      },
    ],
    false
  ).then(id => {
    console.log('New listener subscription ID:', id);
    this.listenerSub = id;
  });
}

  public listenMessages = (messageIds: string[], relIds: string[]) => {
    if (this.messageListenerSub) {
      this.unsub(this.messageListenerSub).then();
    }

    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.EventDeletion, NostrKind.ChannelMessage, NostrKind.Reaction],
        '#e': messageIds,
      },
      ...chunk(relIds, 10).map(c => ({
        kinds: [NostrKind.EventDeletion],
        '#e': c,
      })),
    ];

    this.sub(filters, false).then(r => {
      this.messageListenerSub = r;
    });
  };
  // fetch_notes
  public async updateProfile(profile: Metadata) {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.Metadata],
        authors: [this.pub],
      },
    ];
    const latestEv = (await this.fetch(filters)).sort(
      (a, b) => b.created_at - a.created_at
    )[0];
    const latest = latestEv?.content ? Raven.parseJson(latestEv?.content) : '';
    const update =
      latest.constructor === Object
        ? { ...latest, ...profile }
        : { ...profile };
    return this.publish(NostrKind.Metadata, [], JSON.stringify(update));
  }

  public async getProfile(pubkey: any) {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.Metadata],
        authors: [pubkey],
      },
    ];
    const user = await this.fetch(filters);
    return user[0];
  }

  public async fetchStockNote() {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.Text],
        limit: 100,
      },
    ];

    const stockNotes = await this.fetch(filters);
    const promises = stockNotes.map(async item => {
      const user = await this.getProfile(item.pubkey);
      return {
        ...item,
        user: user,
      };
    });

    const stockNotesWithUser = await Promise.all(promises);
    return stockNotesWithUser;
  }

  public async createStall(stall: Stall): Promise<NostrEvent> {
    // TODO: Implement stall creation
    throw new Error("Method not implemented.");
  }

  public async fetchStalls(): Promise<Stall[]> {
    // Implement the logic to fetch stalls from the Nostr network
    // This is just a placeholder, replace with actual implementation
    const stallEvents = await this.fetch([{ kinds: [NostrKind.MarketStall] }]);
    return stallEvents.map(event => {
      const content = JSON.parse(event.content);
      return {
        id: event.id,
        merchant_id: event.pubkey,
        name: content.name,
        description: content.description,
        currency: content.currency,
        shipping: content.shipping,
      };
    });
  }

  public async fetchProducts(): Promise<Product[]> {
    // Implement the logic to fetch products from the Nostr network
    // This is just a placeholder, replace with actual implementation
    const productEvents = await this.fetch([{ kinds: [NostrKind.MarketProduct] }]);
    return productEvents.map(event => {
      const content = JSON.parse(event.content);
      return {
        id: event.id,
        stall_id: content.stall_id,
        name: content.name,
        description: content.description,
        images: content.images,
        currency: content.currency,
        price: content.price,
        quantity: content.quantity,
        specs: content.specs,
        shipping: content.shipping,
      };
    });
  }  

  public async updateStall(stall: Stall): Promise<NostrEvent> {
    // TODO: Implement stall update
    throw new Error("Method not implemented.");
  }

public async createProduct(productDetails: Product): Promise<NostrEvent> {
  const content = JSON.stringify(productDetails);
  return this.publish(30018, [['e', productDetails.id]], content);
}

  public async updateProduct(product: Product): Promise<NostrEvent> {
    const content = JSON.stringify(product);
    return this.publish(30018, [['e', product.id]], content);
  }

  public async createProposal(proposal: Proposal): Promise<NostrEvent> {
    const content = JSON.stringify(proposal);
    return this.publish(NostrKind.ChannelCreation, [], content);
  }

public async updateProposal(proposal: Proposal): Promise<NostrEvent> {
  const content = JSON.stringify(proposal);
  return this.publish(NostrKind.ChannelMetadata, [['e', proposal.id]], content);
}

  public async createOrder(order: Order): Promise<NostrEvent> {
    // TODO: Implement order creation
    throw new Error("Method not implemented.");
  }

  public async updateOrderStatus(orderId: string, status: OrderStatus): Promise<NostrEvent> {
    // TODO: Implement order status update
    throw new Error("Method not implemented.");
  }

  public async searchOnNostr(text: string) {
    const filters: (NostrFilter | ExtendedFilter)[] = [
      {
        kinds: [NostrKind.Text],
        '#t': [`${text}`],
        limit: 100,
      },
    ];

    const searchresult = await this.fetch(filters);
    const promises = searchresult.map(async item => {
      const user = await this.getProfile(item.pubkey);
      return {
        ...item,
        user: user,
      };
    });

    const searchedNotesEvents = await Promise.all(promises);
    return searchedNotesEvents;
  }

  public async createChannel(meta: Metadata) {
    const createdChannel = this.publishChannel(
      NostrKind.ChannelCreation,
      [],
      JSON.stringify(meta)
    );
    createdChannel.then(res => {
      var about = JSON.parse(meta.about)
      about.proposalID = res.id
      meta.about=JSON.stringify(about)
      return this.bgRaven.where(res.id).then(relay => {
        this.publish(
          NostrKind.ChannelMetadata,
          [['p', plateformProposalKey, relay]],
          JSON.stringify(meta)
        );
      });
    });
    return createdChannel;
  }

  public async updateChannel(channel: Channel, meta: Metadata) {
    console.log('this is metadata', meta);
    return this.bgRaven.where(channel.id).then(relay => {
      return this.publish(
        NostrKind.ChannelMetadata,
        [['e', channel.id, relay]],
        JSON.stringify(meta)
      );
    });
  }

  public async voteOnProposal(channel: Channel, meta: Metadata) {
    return this.bgRaven.where(channel.id).then(relay => {
      return this.publish(
        NostrKind.ChannelMetadata,
        [['e', channel.id, relay]],
        JSON.stringify(meta)
      );
    });
  }

  public async deleteEvents(ids: string[], why: string = '') {
    return this.publish(NostrKind.EventDeletion, [...ids.map(id => ['e', id])], why);
  }

  public async sendPublicMessage(
    channel: Channel,
    message: string,
    mentions?: string[],
    parent?: string
  ) {
    const root = parent || channel.id;
    const relay = await this.bgRaven.where(root);
    const tags = [['e', root, relay, 'root']];
    if (mentions) {
      mentions.forEach(m => tags.push(['p', m]));
    }
    return this.publish(NostrKind.ChannelMessage, tags, message);
  }

  public async createNote(
    message: string,
    doneCreateNote: Function,
    nsec: any
  ) {
    const tags = [
      ['p', 'eea4fcc3c8797becfe978226622824e8da47122ab6fe54d017b1464d78c4cde6'],
    ];
    const createdNote = await this.publishNote(NostrKind.Text, tags, message);
    doneCreateNote(createdNote);
    registerDataOnChain(nsec, createdNote, createdNote.content);
    toast('Note Created');
  }

public async sendDirectMessage(
  toPubkey: string,
  message: string,
  mentions?: string[],
  parent?: string
) {
  console.log('sendDirectMessage called', { toPubkey, message, mentions, parent });
  const encrypted = await this.encrypt(toPubkey, message);
  console.log('Encrypted message:', encrypted);
  const tags = [['p', toPubkey]];
  if (mentions) {
    mentions.forEach(m => tags.push(['p', m]));
  }
  if (parent) {
    const relay = await this.bgRaven.where(parent);
    tags.push(['e', parent, relay, 'root']);
  }
  console.log('Tags for direct message:', tags);
  return this.publish(NostrKind.EncryptedDirectMessage, tags, encrypted);
}

  public async recommendRelay(relay: string) {
    return this.publish(NostrKind.RecommendRelay, [], relay);
  }

  public async hideChannelMessage(id: string, reason: string) {
    return this.publish(
      NostrKind.ChannelHideMessage,
      [['e', id]],
      JSON.stringify({ reason })
    );
  }

  public async muteChannelUser(pubkey: string, reason: string) {
    return this.publish(
      NostrKind.ChannelMuteUser,
      [['p', pubkey]],
      JSON.stringify({ reason })
    );
  }

  public async updateMuteList(userIds: string[]) {
    const list = [...userIds.map(id => ['p', id])];
    const content = await this.encrypt(this.pub, JSON.stringify(list));
    return this.publish(NewKinds.MuteList, [], content);
  }

  public async sendReaction(message: string, pubkey: string, reaction: string) {
    const relay = await this.bgRaven.where(message);
    const tags = [
      ['e', message, relay, 'root'],
      ['p', pubkey],
    ];
    return this.publish(NostrKind.Reaction, tags, reaction);
  }

  public async updateLeftChannelList(channelIds: string[]) {
    const tags = [['d', 'left-channel-list']];
    return this.publish(NewKinds.Arbitrary, tags, JSON.stringify(channelIds));
  }

  public async updateReadMarkMap(map: ReadMarkMap) {
    const tags = [['d', 'read-mark-map']];
    return this.publish(NewKinds.Arbitrary, tags, JSON.stringify(map));
  }

private publish(
  kind: number,
  tags: Array<any>[],
  content: string
): Promise<NostrEvent> {
  console.log('publish method called', { kind, tags, content });
  return new Promise((resolve, reject) => {
    const pool = new SimplePool();

    this.signEvent({
      kind,
      tags,
      pubkey: this.pub,
      content,
      created_at: Math.floor(Date.now() / 1000),

    })
      .then(event => {
        if (!event) {
          console.error("Couldn't sign event!");
          reject("Couldn't sign event!");
          return;
        }

        console.log('Signed event:', event);
        this.pushToEventBuffer(event);

        let resolved = false;
        const okRelays: string[] = [];
        const failedRelays: string[] = [];

        console.log('Publishing to relays:', this.writeRelays);
        const pub = pool.publish(this.writeRelays, event);

        const closePool = () => {
          if (
            [...okRelays, ...failedRelays].length === this.writeRelays.length
          ) {
            pool.close(this.writeRelays);
          }
        };

        pub.on('ok', (r: string) => {
          console.log('Successfully published to relay:', r);
          okRelays.push(r);
          if (!resolved) {
            resolve(event);
            resolved = true;
          }
          closePool();
        });

        pub.on('failed', (r: string) => {
          console.error('Failed to publish to relay:', r);
          failedRelays.push(r);
          if (failedRelays.length === this.writeRelays.length) {
            reject("Event couldn't be published on any relay!");
          }
          closePool();
        });
      })
      .catch((error) => {
        console.error("Couldn't publish event:", error);
        reject("Couldn't publish event!");
      })
      .finally(() => {
        pool.close(this.writeRelays);
      });
  });
}
  private publishChannel(
    kind: number,
    tags: Array<any>[],
    content: string
  ): Promise<NostrEvent> {
    return new Promise((resolve, reject) => {
      const pool = new SimplePool();

      this.signEvent({
        kind,
        tags,
        pubkey: this.pub,
        content,
        created_at: Math.floor(Date.now() / 1000),
      })
        .then(event => {
          if (!event) {
            reject("Couldn't sign event!");
            return;
          }

          this.pushToEventBuffer(event);

          let resolved = false;
          const okRelays: string[] = [];
          const failedRelays: string[] = [];

          const pub = pool.publish(this.writeRelays, event);

          const closePool = () => {
            if (
              [...okRelays, ...failedRelays].length === this.writeRelays.length
            ) {
              pool.close(this.writeRelays);
            }
          };

          pub.on('ok', (r: string) => {
            okRelays.push(r);
            if (!resolved) {
              resolve(event);
              resolved = true;
            }
            closePool();
          });

          pub.on('failed', (r: string) => {
            failedRelays.push(r);
            if (failedRelays.length === this.writeRelays.length) {
              reject("Event couldn't be published on any relay!");
            }
            closePool();
          });
        })
        .catch(() => {
          reject("Couldn't publish event!");
        })
        .finally(() => {
          pool.close(this.writeRelays);
        });
    });
  }

  private publishNote(
    kind: number,
    tags: Array<any>[],
    content: string
  ): Promise<NostrEvent> {
    return new Promise((resolve, reject) => {
      const pool = new SimplePool();

      this.signEvent({
        kind,
        tags,
        pubkey: this.pub,
        content,
        created_at: Math.floor(Date.now() / 1000),
      })
        .then(event => {
          if (!event) {
            reject("Couldn't sign event!");
            return;
          }

          this.pushToEventBuffer(event);

          let resolved = false;
          const okRelays: string[] = [];
          const failedRelays: string[] = [];

          const pub = pool.publish(this.writeRelays, event);

          const closePool = () => {
            if (
              [...okRelays, ...failedRelays].length === this.writeRelays.length
            ) {
              pool.close(this.writeRelays);
            }
          };

          pub.on('ok', (r: string) => {
            okRelays.push(r);
            if (!resolved) {
              resolve(event);
              resolved = true;
            }
            closePool();
          });

          pub.on('failed', (r: string) => {
            failedRelays.push(r);
            if (failedRelays.length === this.writeRelays.length) {
              reject("Event couldn't be published on any relay!");
            }
            toast.error("Event couldn't be published on any relay!");

            closePool();
          });
        })
        .catch(() => {
          reject("Couldn't publish event!");
        })
        .finally(() => {
          pool.close(this.writeRelays);
        });
    });
  }

  private async encrypt(pubkey: string, content: string) {
    if (this.priv === 'nip07') {
      if (!window.nostr?.nip04) throw new Error('NIP-04 not supported');
      return window.nostr.nip04.encrypt(pubkey, content);
    } else {
      const priv =
        this.priv === 'none'
          ? await window.requestPrivateKey({ pubkey, content })
          : this.priv;
      return nip04.encrypt(priv, pubkey, content);
    }
  }

  private async signEvent(event: Omit<NostrEvent, 'id' | 'sig'>): Promise<NostrEvent> {
    if (this.priv === 'nip07') {
      if (!window.nostr?.signEvent) throw new Error('signEvent not supported');
      return window.nostr.signEvent(event);
    } else {
      const priv =
        this.priv === 'none'
          ? await window.requestPrivateKey(event)
          : this.priv;
      const eventWithId = {
        ...event,
        id: utils.getEventHash(event as NostrEvent),
      };
      return {
        ...eventWithId,
        sig: utils.signEvent(eventWithId as NostrEvent, priv),
      };
    }
  }

  private convertToProfile(event: NostrEvent): Profile {
    const content = Raven.parseJson(event.content);
    return {
      id: event.id,
      creator: event.pubkey,
      created: event.created_at,
      ...Raven.normalizeMetadata(content),
      nip05: content?.nip05 || '',
    };
  }

  private convertToChannel(event: NostrEvent): Channel {
    const content = Raven.parseJson(event.content);
    return {
      id: event.id,
      creator: event.pubkey,
      created: event.created_at,
      ...Raven.normalizeMetadata(content),
    };
  }

  private convertToChannelUpdate(event: NostrEvent): ChannelUpdate {
    const content = Raven.parseJson(event.content);
    return {
      id: event.id,
      channelId: Raven.findTagValue(event, 'e') || '',
      creator: event.pubkey,
      created: event.created_at,
      ...Raven.normalizeMetadata(content),
    };
  }

  private convertToEventDeletion(event: NostrEvent): EventDeletion {
    return {
      eventId: event.tags.find(([t]) => t === 'e')?.[1] || '',
      why: event.content,
    };
  }

  private convertToPublicMessage(event: NostrEvent): PublicMessage {
    return {
      id: event.id,
      root: Raven.findTagValue(event, 'e') || '',
      content: event.content,
      creator: event.pubkey,
      created: event.created_at,
      mentions: event.tags.filter(([t]) => t === 'p').map(([_, v]) => v),
      proposalID: Raven.findTagValue(event, 'e') || '',
      tags: event.tags as [string, string][],
    };
  }

  private convertToDirectMessage(event: NostrEvent): DirectMessage {
    return {
      id: event.id,
      root: Raven.findTagValue(event, 'e') || '',
      content: event.content,
      peer: Raven.findTagValue(event, 'p') || '',
      creator: event.pubkey,
      created: event.created_at,
      mentions: event.tags.filter(([t]) => t === 'p').map(([_, v]) => v),
      decrypted: false,
      proposalID: Raven.findTagValue(event, 'e') || '',
      tags: event.tags as [string, string][],
    };
  }

  private convertToChannelMessageHide(event: NostrEvent): ChannelMessageHide {
    const content = Raven.parseJson(event.content);
    return {
      id: event.id,
      reason: content?.reason || '',
    };
  }

  private convertToChannelUserMute(event: NostrEvent): ChannelUserMute {
    const content = Raven.parseJson(event.content);
    return {
      pubkey: Raven.findTagValue(event, 'p') || '',
      reason: content?.reason || '',
    };
  }

  private convertToMuteList(event: NostrEvent): MuteList {
    return {
      pubkeys: event.tags.filter(([t]) => t === 'p').map(([_, v]) => v),
      encrypted: event.content,
    };
  }

  private convertToReaction(event: NostrEvent): Reaction {
    return {
      id: event.id,
      message: Raven.findTagValue(event, 'e') || '',
      peer: Raven.findTagValue(event, 'p') || '',
      content: event.content,
      creator: event.pubkey,
      created: event.created_at,
    };
  }

  private convertToReadMarkMap(event: NostrEvent): ReadMarkMap {
    const content = Raven.parseJson(event.content);
    return content || {};
  }

  private convertToEventSuggestion(event: NostrEvent): EventSuggestion {
    return {
      id: event.id,
      root: Raven.findTagValue(event, 'e') || '',
      content: event.content,
      creator: event.pubkey,
      created: event.created_at,
      mentions: event.tags.filter(([t]) => t === 'p').map(([_, v]) => v),
      proposalID: Raven.findTagValue(event, 'e') || '',
    };
  }

  private async processEvents() {
    this.eventQueueFlag = false;
    const events = [...this.eventQueue];
    this.eventQueue = [];

    // Process events by kind and convert them
    const profiles = events.filter(x => x.kind === NostrKind.Metadata).map(x => this.convertToProfile(x));
    const channels = events.filter(x => x.kind === NostrKind.ChannelCreation).map(x => this.convertToChannel(x));
    const channelUpdates = events.filter(x => x.kind === NostrKind.ChannelMetadata).map(x => this.convertToChannelUpdate(x));
    const eventDeletions = events.filter(x => x.kind === NostrKind.EventDeletion).map(x => this.convertToEventDeletion(x));
    const publicMessages = events.filter(x => x.kind === NostrKind.ChannelMessage).map(x => this.convertToPublicMessage(x));
    const directMessages = events.filter(x => x.kind === NostrKind.EncryptedDirectMessage).map(x => this.convertToDirectMessage(x));
    const channelMessageHides = events.filter(x => x.kind === NostrKind.ChannelHideMessage).map(x => this.convertToChannelMessageHide(x));
    const channelUserMutes = events.filter(x => x.kind === NostrKind.ChannelMuteUser).map(x => this.convertToChannelUserMute(x));
    const muteLists = events.filter(x => x.kind === NewKinds.MuteList).map(x => this.convertToMuteList(x));
    const reactions = events.filter(x => x.kind === NostrKind.Reaction).map(x => this.convertToReaction(x));
    const readMarkMaps = events.filter(x => x.kind === NewKinds.Arbitrary).map(x => this.convertToReadMarkMap(x));
    const calendarSuggestions = events.filter(x => x.kind === NewKinds.CalendarSuggestion).map(x => this.convertToEventSuggestion(x));

    // Emit events
    if (profiles.length > 0) this.emit(RavenEvents.ProfileUpdate, profiles);
    if (channels.length > 0) this.emit(RavenEvents.ChannelCreation, channels);
    if (channelUpdates.length > 0) this.emit(RavenEvents.ChannelUpdate, channelUpdates);
    if (eventDeletions.length > 0) this.emit(RavenEvents.EventDeletion, eventDeletions);
    if (publicMessages.length > 0) this.emit(RavenEvents.PublicMessage, publicMessages);
    if (directMessages.length > 0) this.emit(RavenEvents.DirectMessage, directMessages);
    if (channelMessageHides.length > 0) this.emit(RavenEvents.ChannelMessageHide, channelMessageHides);
    if (channelUserMutes.length > 0) this.emit(RavenEvents.ChannelUserMute, channelUserMutes);
    if (muteLists.length > 0) this.emit(RavenEvents.MuteList, muteLists[0]);
    if (reactions.length > 0) this.emit(RavenEvents.Reaction, reactions);
    if (readMarkMaps.length > 0) this.emit(RavenEvents.ReadMarkMap, readMarkMaps[0]);
    if (calendarSuggestions.length > 0) this.emit(RavenEvents.CalendarSuggestion, calendarSuggestions);

    this.eventQueueFlag = true;
    if (this.eventQueueBuffer.length > 0) {
      const buffer = [...this.eventQueueBuffer];
      this.eventQueueBuffer = [];
      buffer.forEach(e => this.pushToEventBuffer(e));
    }
  }

  pushToEventBuffer(event: NostrEvent) {
    const cacheKey = `${event.id}_emitted`;
    if (this.nameCache[cacheKey] === undefined) {
      if (this.eventQueueFlag) {
        if (this.eventQueueBuffer.length > 0) {
          this.eventQueue.push(...this.eventQueueBuffer);
          this.eventQueueBuffer = [];
        }
        clearTimeout(this.eventQueueTimer);
        this.eventQueue.push(event);
        this.eventQueueTimer = setTimeout(() => {
          this.processEvents().then();
        }, 50);
      } else {
        this.eventQueueBuffer.push(event);
      }

      this.nameCache[cacheKey] = 1;
    }
  }

private async decrypt(pubkey: string, content: string): Promise<string> {
    if (this.priv === 'nip07') {
      if (!window.nostr?.nip04) throw new Error('NIP-04 not supported');
      return window.nostr.nip04.decrypt(pubkey, content);
    }
    const priv = this.priv === 'none'
      ? await window.requestPrivateKey({ pubkey, content })
      : this.priv;
    return nip04.decrypt(priv, pubkey, content);
  }
}
