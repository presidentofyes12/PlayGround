import {
  Channel,
  ChannelMessageHide,
  ChannelUpdate,
  ChannelUserMute,
  DirectMessage,
  EventDeletion,
  Keys,
  Metadata,
  MuteList,
  Profile,
  PublicMessage,
  Reaction,
  ReadMarkMap,
  RelayDict,
  OrderStatus,
  Order,
  Product,
  Stall,
  Proposal
} from "types";

export interface NostrEvent {
  id: string;
  pubkey: string;
  created_at: number;
  kind: number;
  tags: string[][];
  content: string;
  sig: string;
}

export type NostrEventToSign = Omit<NostrEvent, "id" | "sig">;

export interface NostrFilter {
  ids?: string[];
  authors?: string[];
  kinds?: number[];
  "#e"?: string[];
  "#p"?: string[];
  "#t"?: string[];
  since?: number;
  until?: number;
  limit?: number;
}

export interface NostrSub {
  on: (event: string, callback: (event: NostrEvent) => void) => void;
  off: (event: string, callback: (event: NostrEvent) => void) => void;
  unsub: () => void;
}

export interface NostrSimplePool {
  sub: (relays: string[], filters: NostrFilter[], opts?: { id?: string }) => NostrSub;
  list: (relays: string[], filters: NostrFilter[], timeout?: number) => Promise<NostrEvent[]>;
  seenOn: (eventId: string) => string[];
}

export enum NostrKind {
  Metadata = 0,
  Text = 1,
  RecommendRelay = 2,
  Contacts = 3,
  EncryptedDirectMessage = 4,
  EventDeletion = 5,
  Repost = 6,
  Reaction = 7,
  ChannelCreation = 40,
  ChannelMetadata = 41,
  ChannelMessage = 42,
  ChannelHideMessage = 43,
  ChannelMuteUser = 44,
  Blank = 255,
  Report = 1984,
  ZapRequest = 9734,
  Zap = 9735,
  RelayList = 10002,
  ClientAuth = 22242,
  NWCWalletRequest = 23194,
  NWCWalletResponse = 23195,
  NostrConnect = 24133,
  CategorizedHighlight = 9802,
  HighlightMarker = 9802,
  BadgeAward = 8,
  ProfileBadge = 30008,
  BadgeDefinition = 30009,
  MarketStall = 30017,
  MarketProduct = 30018,
  Article = 30023,
  ApplicationSpecificData = 30078
}

export enum NewKinds {
  MuteList = 10000,
  Arbitrary = 30078,
  CalendarSuggestion = 30079,
}

export type AllKinds = NostrKind | NewKinds;

export type ExtendedFilter = Omit<NostrFilter, "kinds"> & { kinds?: AllKinds[] };

export type ExtendedKind = NostrKind | NewKinds;

export interface RavenEventHandlerMap {
  ready: () => void;
  dms_done: () => void;
  sync_done: () => void;
  profile_update: (data: Profile[]) => void;
  channel_creation: (data: Channel[]) => void;
  channel_update: (data: ChannelUpdate[]) => void;
  event_deletion: (data: EventDeletion[]) => void;
  public_message: (data: PublicMessage[]) => void;
  direct_message: (data: DirectMessage[]) => void;
  channel_message_hide: (data: ChannelMessageHide[]) => void;
  channel_user_mute: (data: ChannelUserMute[]) => void;
  mute_list: (data: MuteList) => void;
  left_channel_list: (data: string[]) => void;
  reaction: (data: Reaction[]) => void;
  read_mark_map: (data: ReadMarkMap) => void;
  calendar_suggestion: (data: EventSuggestion[]) => void;
}

export interface EventSuggestion {
  id: string;
  root: string;
  content: string;
  creator: string;
  created: number;
  mentions: string[];
  proposalID: string;
  finalDateTime?: string;
}
