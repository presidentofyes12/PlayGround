import React from 'react';
import { RouteComponentProps } from '@reach/router';

const OrderHistory: React.FC<RouteComponentProps> = () => {
  return <div>Order History placeholder</div>;
};

export default OrderHistory;