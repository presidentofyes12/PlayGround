import { NostrEvent, NostrFilter, NostrSimplePool } from "../../../types/nostr";
import { getRelays } from "local-storage";
import { Stall, Product } from "./types";
import { RelayDict } from "types";

let pool: NostrSimplePool;
let relays: string[];

getRelays().then(r => {
  relays = Object.keys(r);
  pool = {
    sub: (relays, filters, opts) => ({
      on: () => {},
      off: () => {},
      unsub: () => {}
    }),
    list: async (relays, filters, timeout) => [],
    seenOn: (eventId) => []
  };
});

export async function fetchStalls(): Promise<Stall[]> {
  const filters: NostrFilter[] = [{ kinds: [30017] }];
  const events = await pool.list(relays, filters);
  return events.map((event: NostrEvent) => JSON.parse(event.content));
}

export async function fetchProducts(): Promise<Product[]> {
  const filters: NostrFilter[] = [{ kinds: [30018] }];
  const events = await pool.list(relays, filters);
  return events.map((event: NostrEvent) => JSON.parse(event.content));
}

async function fetchEvents(filters: NostrFilter[], timeout: number = 0): Promise<NostrEvent[]> {
  const events = await pool.list(relays, filters, timeout);
  return events;
}
