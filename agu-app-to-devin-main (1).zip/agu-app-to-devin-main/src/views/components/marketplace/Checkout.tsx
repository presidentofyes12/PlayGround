import React from 'react';
import { RouteComponentProps } from '@reach/router';

const Checkout: React.FC<RouteComponentProps> = () => {
  return <div>Checkout placeholder</div>;
};

export default Checkout;