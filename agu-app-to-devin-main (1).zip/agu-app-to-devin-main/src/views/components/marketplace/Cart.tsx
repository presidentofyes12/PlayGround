import React from 'react';
import { RouteComponentProps } from '@reach/router';

const Cart: React.FC<RouteComponentProps> = () => {
  return <div>Cart placeholder</div>;
};

export default Cart;