import React, { useState, useEffect } from "react";
import { useAtom } from "jotai";
import { ravenAtom, keysAtom } from "atoms";
import { NostrEvent } from "../../../types/nostr";
import useTranslation from "hooks/use-translation";

interface EventSuggestion {
  id: string;
  root: string;
  content: string;
  creator: string;
  created: number;
  mentions: string[];
  proposalID: string;
  finalDateTime?: string;
}

const OldCalendar: React.FC = () => {
  const [t] = useTranslation();
  const [raven] = useAtom(ravenAtom);
  const [keys] = useAtom(keysAtom);
  const [eventSuggestions, setEventSuggestions] = useState<EventSuggestion[]>([]);

  const fetchEventSuggestions = async () => {
    if (!raven || !keys) return;

    try {
      const messages = await raven.fetchAllProposal();
      console.log("Fetched messages:", messages);

      const newSuggestions = messages
        .filter((msg: NostrEvent) => {
          try {
            const content = JSON.parse(msg.content);
            return content.type === "event_suggestion" && content.timeRange && content.dateRange;
          } catch (e) {
            console.log(`Error parsing message ${msg.id}:`, e);
            return false;
          }
        })
        .map((msg: NostrEvent) => ({
          id: msg.id,
          root: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
          content: msg.content,
          creator: msg.pubkey,
          created: msg.created_at,
          mentions: msg.tags.filter((tag: string[]) => tag[0] === "p").map((tag: string[]) => tag[1]),
          proposalID: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
        }));

      console.log("New suggestions:", newSuggestions);

      setEventSuggestions(prevSuggestions => {
        const existingIds = new Set(prevSuggestions.map(s => s.id));
        const uniqueNewSuggestions = newSuggestions.filter(s => !existingIds.has(s.id));
        console.log("Unique new suggestions:", uniqueNewSuggestions);
        const updatedSuggestions = [...prevSuggestions, ...uniqueNewSuggestions];
        console.log("Updated event suggestions:", updatedSuggestions);
        return updatedSuggestions;
      });
    } catch (error) {
      console.error("Error fetching event suggestions:", error);
    }
  };

  useEffect(() => {
    if (raven && keys) {
      fetchEventSuggestions();
    }
  }, [raven, keys]);

  return (
    <div>
      <h1>{t("Calendar")}</h1>
      <div>
        {eventSuggestions.map(suggestion => (
          <div key={suggestion.id}>
            <p>{suggestion.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OldCalendar;
