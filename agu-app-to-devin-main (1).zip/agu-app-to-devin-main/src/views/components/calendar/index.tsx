import React, { useState, useEffect, useCallback } from "react";
import { useAtom } from "jotai";
import {
  Box,
  Slider,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  CircularProgress,
  Snackbar,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from "@mui/material";
import { ravenAtom, profilesAtom, channelAtom, activeProposalIdAtom, keysAtom, directMessagesAtom } from "atoms";
import { NewKinds, RavenEvents, ExtendedFilter, ExtendedKind } from "raven/raven";
import useTranslation from "hooks/use-translation";
import { formatMessageDateTime } from "helper";
import { RouteComponentProps } from "@reach/router";
import { nip19 } from "nostr-tools";
import useLiveDirectContacts from "hooks/use-live-direct-contacts";
import { Helmet } from "react-helmet";
import AppWrapper from "views/components/app-wrapper";
import AppMenu from "views/components/app-menu";
import AppContent from "views/components/app-content";
import { NostrEvent } from "../../../types/nostr";

interface CalendarProps extends RouteComponentProps {}

export interface EventSuggestion {
  id: string;
  root: string;
  content: string;
  creator: string;
  created: number;
  mentions: string[];
  proposalID: string;
  finalDateTime?: string;
}

const Calendar: React.FC<CalendarProps> = () => {
  const [t] = useTranslation();
  const [raven] = useAtom(ravenAtom);
  const [profiles] = useAtom(profilesAtom);
  const [channel] = useAtom(channelAtom);
  const [activeProposalId] = useAtom(activeProposalIdAtom);
  const [keys] = useAtom(keysAtom);
  const [directMessages] = useAtom(directMessagesAtom);
  const directContacts = useLiveDirectContacts();

  const [eventSuggestions, setEventSuggestions] = useState<EventSuggestion[]>([]);
  const [finalizedEvents, setFinalizedEvents] = useState<EventSuggestion[]>([]);
  const [selectedContact, setSelectedContact] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [snackbarMessage, setSnackbarMessage] = useState<string | null>(null);

  const fetchEventSuggestions = useCallback(async (isInitialLoad = false) => {
    if (!raven || !keys) {
      return;
    }
    if (isInitialLoad) {
      setIsLoading(true);
    }
    try {
      const messages = await raven.fetchCalendarSuggestions();
      const newSuggestions: EventSuggestion[] = [];
      const newFinalizedEvents: EventSuggestion[] = [];

      messages.forEach((msg: NostrEvent) => {
        const content = JSON.parse(msg.content);
        if (content.type === "event_suggestion") {
          newSuggestions.push({
            id: msg.id,
            root: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
            content: msg.content,
            creator: msg.pubkey,
            created: msg.created_at,
            mentions: msg.tags.filter((tag: string[]) => tag[0] === "p").map((tag: string[]) => tag[1]),
            proposalID: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
          });
        } else if (content.type === "event_finalized") {
          newFinalizedEvents.push({
            id: msg.id,
            root: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
            content: msg.content,
            creator: msg.pubkey,
            created: msg.created_at,
            mentions: msg.tags.filter((tag: string[]) => tag[0] === "p").map((tag: string[]) => tag[1]),
            proposalID: msg.tags.find((tag: string[]) => tag[0] === "e")?.[1] || "",
            finalDateTime: content.finalDateTime,
          });
        }
      });

      setEventSuggestions(prevSuggestions => {
        const existingIds = new Set(prevSuggestions.map(s => s.id));
        const uniqueNewSuggestions = newSuggestions.filter(s => !existingIds.has(s.id));
        return [...prevSuggestions, ...uniqueNewSuggestions];
      });

      setFinalizedEvents(prevEvents => {
        const existingIds = new Set(prevEvents.map(e => e.id));
        const uniqueNewEvents = newFinalizedEvents.filter(e => !existingIds.has(e.id));
        return [...prevEvents, ...uniqueNewEvents];
      });
    } catch (error) {
      setSnackbarMessage(t("Failed to fetch event suggestions. Please try again."));
    } finally {
      if (isInitialLoad) {
        setIsLoading(false);
      }
    }
  }, [raven, keys, t]);

  useEffect(() => {
    if (raven && keys) {
      fetchEventSuggestions(true);
      const interval = setInterval(() => fetchEventSuggestions(false), 30000);
      return () => clearInterval(interval);
    }
  }, [raven, keys, fetchEventSuggestions]);

  return (
    <AppWrapper>
      <AppMenu />
      <AppContent>
        <Box>
          <Typography variant="h4">{t("Calendar")}</Typography>
          {isLoading ? (
            <CircularProgress />
          ) : (
            <>
              <Box>
                <Typography variant="h5">{t("Event Suggestions")}</Typography>
                {eventSuggestions.map(suggestion => (
                  <Box key={suggestion.id}>
                    <Typography>{suggestion.content}</Typography>
                  </Box>
                ))}
              </Box>
              <Box>
                <Typography variant="h5">{t("Finalized Events")}</Typography>
                {finalizedEvents.map(event => (
                  <Box key={event.id}>
                    <Typography>{event.content}</Typography>
                  </Box>
                ))}
              </Box>
            </>
          )}
        </Box>
        <Snackbar
          open={!!snackbarMessage}
          autoHideDuration={6000}
          onClose={() => setSnackbarMessage(null)}
          message={snackbarMessage}
        />
      </AppContent>
    </AppWrapper>
  );
};

export default Calendar;
