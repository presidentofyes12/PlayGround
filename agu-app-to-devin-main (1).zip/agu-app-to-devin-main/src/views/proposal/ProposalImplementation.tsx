import React from 'react';
import { Box, Typography, LinearProgress, Button, Grid } from '@mui/material';

interface Props {
  proposal: any; // Will update with proper type once we update types
}

const ProposalImplementation: React.FC<Props> = ({ proposal }) => {
  const handleProgressUpdate = async () => {
    try {
      // TODO: Implement progress update logic
      console.log('Progress update requested');
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  };

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3 }}>Implementation Progress</Typography>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6">Overall Progress</Typography>
        <LinearProgress 
          variant="determinate" 
          value={proposal?.currentValue || 0} 
          sx={{ height: 10, borderRadius: 5 }}
        />
      </Box>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6">Component Progress</Typography>
        <Grid container spacing={2}>
          {(proposal?.components || [0, 0, 0]).map((value: number, index: number) => (
            <Grid item xs={12} key={index}>
              <Typography>Component {index + 1}</Typography>
              <LinearProgress 
                variant="determinate" 
                value={Math.max(0, value)} 
                sx={{ height: 8, borderRadius: 4 }}
              />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6">Team Members</Typography>
        {(proposal?.teamMembers || []).map((member: string, index: number) => (
          <Typography key={index}>{member}</Typography>
        ))}
      </Box>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6">Child Proposals</Typography>
        {(proposal?.childProposals || []).map((childId: string, index: number) => (
          <Button key={index} variant="outlined" href={`/proposal/${childId}`}>
            View Child Proposal {index + 1}
          </Button>
        ))}
      </Box>

      <Button variant="contained" onClick={handleProgressUpdate}>
        Update Progress
      </Button>
    </Box>
  );
};

export default ProposalImplementation;