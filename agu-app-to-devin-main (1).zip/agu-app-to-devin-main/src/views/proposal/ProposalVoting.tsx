import React, { useState } from 'react';
import { Box, Typography, Slider, Button, Checkbox, FormControlLabel } from '@mui/material';

interface Props {
  proposal: any; // Will update with proper type once we update types
}

const ProposalVoting: React.FC<Props> = ({ proposal }) => {
  const [approval, setApproval] = useState<boolean>(false);
  const [priorityScore, setPriorityScore] = useState<number>(50);
  const [implementationInterest, setImplementationInterest] = useState<boolean>(false);
  const [conceptScores, setConceptScores] = useState<number[]>(new Array(9).fill(50));

  const handleVote = async () => {
    try {
      // TODO: Implement voting logic
      console.log('Vote submitted:', {
        approval,
        priorityScore,
        implementationInterest,
        conceptScores
      });
    } catch (error) {
      console.error('Error submitting vote:', error);
    }
  };

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3 }}>Vote on Proposal</Typography>
      
      <FormControlLabel
        control={
          <Checkbox
            checked={approval}
            onChange={(e) => setApproval(e.target.checked)}
          />
        }
        label="Approve Proposal"
      />

      <Box sx={{ my: 3 }}>
        <Typography>Priority Score</Typography>
        <Slider
          value={priorityScore}
          onChange={(_, value) => setPriorityScore(value as number)}
          valueLabelDisplay="auto"
        />
      </Box>

      <FormControlLabel
        control={
          <Checkbox
            checked={implementationInterest}
            onChange={(e) => setImplementationInterest(e.target.checked)}
          />
        }
        label="I am interested in helping implement this proposal"
      />

      <Box sx={{ my: 3 }}>
        <Typography variant="h6">Concept Scores</Typography>
        {['Truth', 'Life', 'Freedom', 'Power', 'Rules', 'Information', 'Justice', 'Community', 'Responsibility'].map((concept, index) => (
          <Box key={concept} sx={{ my: 2 }}>
            <Typography>{concept}</Typography>
            <Slider
              value={conceptScores[index]}
              onChange={(_, value) => {
                const newScores = [...conceptScores];
                newScores[index] = value as number;
                setConceptScores(newScores);
              }}
              valueLabelDisplay="auto"
            />
          </Box>
        ))}
      </Box>

      <Button variant="contained" onClick={handleVote}>
        Submit Vote
      </Button>
    </Box>
  );
};

export default ProposalVoting;