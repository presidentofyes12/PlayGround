import React from 'react';
import { Box, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';

interface Props {
  proposal: any; // Will update with proper type once we update types
}

const ProposalCircularDashboard: React.FC<Props> = ({ proposal }) => {
  const theme = useTheme();

  const generateSVG = () => {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 800 800");
    
    // Background
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("width", "800");
    rect.setAttribute("height", "800");
    rect.setAttribute("fill", theme.palette.background.paper);
    svg.appendChild(rect);
    
    // Title
    const title = document.createElementNS("http://www.w3.org/2000/svg", "text");
    title.setAttribute("x", "400");
    title.setAttribute("y", "40");
    title.setAttribute("font-family", "Arial");
    title.setAttribute("font-size", "24");
    title.setAttribute("text-anchor", "middle");
    title.setAttribute("font-weight", "bold");
    title.textContent = proposal?.title || "Proposal";
    svg.appendChild(title);
    
    return svg;
  };

  return (
    <Box>
      <Typography variant="h6">Proposal Progress</Typography>
      <Box sx={{ position: 'relative', width: '100%', paddingBottom: '100%' }}>
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
          ref={(el: HTMLDivElement | null) => {
            if (el) {
              el.innerHTML = '';
              el.appendChild(generateSVG());
            }
          }}
        />
      </Box>
    </Box>
  );
};

export default ProposalCircularDashboard;