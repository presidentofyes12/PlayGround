import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { RouteComponentProps } from '@reach/router';
import { Card, CardContent, Grid, Box, Typography, CircularProgress } from '@mui/material';
import { useAtom } from 'jotai';
import { channelAtom } from 'atoms';
import AppWrapper from 'views/components/app-wrapper';
import AppMenu from 'views/components/app-menu';
import DashboardContent from 'views/components/app-content/DashboardContent';
import ChannelList from 'views/components/app-menu/channel-list';
import ProposalCircularDashboard from './ProposalCircularDashboard';
import ProposalConceptAssessment from './ProposalConceptAssessment';
import ProposalVoting from './ProposalVoting';
import ProposalImplementation from './ProposalImplementation';
import logo from './AGU_logo_fully_transparent.png';

interface ProposalProps extends RouteComponentProps {
  proposalId?: string;
}

const Proposal = (props: ProposalProps) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [channel] = useAtom(channelAtom);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <>
      <Helmet>
        <title>{channel?.name || 'Proposal'}</title>
      </Helmet>
      <AppWrapper>
        <AppMenu />
        <DashboardContent>
          <Grid container spacing={3}>
            {/* Channel List for Navigation */}
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <div className='proposal_history'>
                    <ChannelList />
                  </div>
                </CardContent>
              </Card>
            </Grid>

            {/* Circular Dashboard */}
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <ProposalCircularDashboard proposal={channel} />
                </CardContent>
              </Card>
            </Grid>

            {/* Concept Assessment */}
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <ProposalConceptAssessment proposal={channel} />
                </CardContent>
              </Card>
            </Grid>

            {/* Voting Section */}
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <ProposalVoting proposal={channel} />
                </CardContent>
              </Card>
            </Grid>

            {/* Implementation Section */}
            <Grid item xs={12}>
              <Card>
                <CardContent>
                  <ProposalImplementation proposal={channel} />
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </DashboardContent>
        <img src={logo} alt="AGU Logo" className="agu-logo" />
      </AppWrapper>
      <style>{`
        .agu-logo {
          position: absolute;
          top: 10px;
          left: 275px;
          width: 200px;
          height: auto;
        }
        .proposal_history {
          position: relative;
        }
      `}</style>
    </>
  );
}

export default Proposal;
