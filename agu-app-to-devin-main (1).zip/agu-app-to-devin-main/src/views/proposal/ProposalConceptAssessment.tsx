import React from 'react';
import { Box, Typography, Grid } from '@mui/material';

interface Props {
  proposal: any; // Will update with proper type once we update types
}

const ProposalConceptAssessment: React.FC<Props> = ({ proposal }) => {
  const renderConceptGroup = (concepts: string[], title: string) => (
    <Box sx={{ mb: 3 }}>
      <Typography variant="h6">{title}</Typography>
      <Grid container spacing={2}>
        {concepts.map(concept => (
          <Grid item xs={12} sm={6} key={concept}>
            <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider' }}>
              <Typography variant="subtitle1">
                {concept.charAt(0).toUpperCase() + concept.slice(1)}
              </Typography>
              <Typography>
                Value: {proposal?.concepts?.[concept.toLowerCase()]?.assessmentValue || 0}%
              </Typography>
              <Typography variant="body2">
                {proposal?.concepts?.[concept.toLowerCase()]?.currentState || 'Not assessed'}
              </Typography>
            </Box>
          </Grid>
        ))}
      </Grid>
    </Box>
  );

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3 }}>Concept Assessment</Typography>
      {renderConceptGroup(['Truth'], 'Foundation')}
      {renderConceptGroup(['Life', 'Freedom'], 'Values')}
      {renderConceptGroup(['Power', 'Rules', 'Information'], 'Mechanisms')}
      {renderConceptGroup(['Justice', 'Community', 'Responsibility'], 'Applications')}
    </Box>
  );
};

export default ProposalConceptAssessment;