import React from 'react';

const DownloadSeedWords: React.FC<{ text: string , title:string }> = ({ text , title }) => {
  const validateContent = (content: string): boolean => {
    // Check if content exists and is a string
    if (!content || typeof content !== 'string') {
      console.error('Invalid content type or empty content');
      return false;
    }

    // Check minimum length (12 words * average 5 chars per word = 60 chars minimum)
    if (content.length < 60) {
      console.error('Content too short to be valid seed words');
      return false;
    }

    // Check if content contains actual words
    const words = content.trim().split(' ');
    if (words.length < 12) {
      console.error('Not enough words in seed phrase');
      return false;
    }

    return true;
  };

  const createFileContent = (seedWords: string): string => {
    const timestamp = new Date().toISOString();
    return `NOSTR SEED WORDS
==================
Generated at: ${timestamp}

IMPORTANT: Keep these words safe and secret!
They are used to recover your account.

${seedWords}

==================
Word count: ${seedWords.split(' ').length} words
Character count: ${seedWords.length} characters`;
  };

  const handleDownload = () => {
    console.log('Validating seed words...');
    
    if (!validateContent(text)) {
      alert('Invalid seed words. Cannot create empty or invalid file.');
      return;
    }
    
    try {
      // Create the file content with header and footer
      const fileContent = createFileContent(text);
      
      // Verify file content
      if (!validateContent(fileContent)) {
        throw new Error('Generated file content is invalid');
      }
      
      // Create blob and verify size
      const file = new Blob([fileContent], { type: 'text/plain' });
      if (file.size === 0) {
        throw new Error('Generated file is empty');
      }
      console.log('File size:', file.size, 'bytes');
      
      // Create and verify URL
      const url = URL.createObjectURL(file);
      if (!url) {
        throw new Error('Failed to create file URL');
      }
      
      // Download file
      const element = document.createElement('a');
      element.href = url;
      element.download = 'nostrSeedWords.txt';
      document.body.appendChild(element);
      
      // Trigger download
      const downloadResult = element.click();
      console.log('Download triggered:', downloadResult);
      
      // Cleanup
      document.body.removeChild(element);
      URL.revokeObjectURL(url);
      
      // Mark as downloaded
      window.localStorage.setItem("downloaded", "true");
      console.log('Download completed successfully');
    } catch (error) {
      console.error('Error during download:', error);
      alert('Failed to download seed words. Please try again.');
    }
  };

  return (
    <button className='btn btn_success'  onClick={handleDownload}>
      {title ? title:'Download Seed Words'}
    </button>
  );
};

export default DownloadSeedWords;
